#ifdef POINT_CLOUD_EXPORTS
#	define CGV_EXPORTS
#endif

#include <cgv/config/lib_begin.h>
